/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoas;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Jéssica Martins de Jesus
 */
public class Pessoa implements Movable {
    ArrayList lista = new ArrayList<>();
    private Random numAleatorio = new Random();
    protected int x,y;
    private int velocidade = 1;
    private int cor;
    protected int whatsapp;
   
    //Cuntructor para o inicio do simulador
    public Pessoa(){
        setX(numAleatorio.nextInt(28));
        setY(numAleatorio.nextInt(58));
        setWhatsapp(numAleatorio.nextInt(100000, 1000000));
    }
    //Contructor geral para quando ocorre a troca de classes
    public Pessoa(int x, int y, int whatsapp, ArrayList lista) {
        this.x = x;
        this.y = y;
        this.whatsapp = whatsapp;
        this.lista = lista;
    }
    
    
    //Adiciona o Whatsapp de um objeto ao ArrayList de outro
    public void AdicionarNaLista(int whatsapp){
        lista.add(whatsapp);
    }
    //imprime a lista do objeto
    public void printLista(ArrayList lista){
        System.out.println(lista);
    }
    //Procura se o Whatsapp requisitado já foi colocado na lista, para evitar repetições
    public boolean lockForWhats(int whatsapp){
        if(lista.contains(whatsapp)){
            return true;
        }else{
            return false;
        }
    }
    
    //Getters e Setters
    public ArrayList getLista() {
        return lista;
    }

    public void setLista(ArrayList lista) {
        this.lista = lista;
    }
    
    public int getWhatsapp() {
        return whatsapp;
    }

    public void setWhatsapp(int whatsapp) {
        this.whatsapp = whatsapp;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public int getCor() {
        return cor;
    }

    public void setCor(int cor) {
        this.cor = cor;
    }
    
    //Metodo usado para mover os objetos pelo mapa. Este movimento é aleatorio e pode ser para cima para baixo, para esquerda ou para direita.
    @Override
    public void mover(){
        int move = numAleatorio.nextInt(4);
        switch(move){
            case 0: 
                y -= getVelocidade();
                if (y<0) {
                    y+=60;
                }else if(y>59){
                    y-=60;
                   
                }break;
            case 1:
                y += getVelocidade();
                if (y<0) {
                    y+=60;
                }else if(y>59){
                    y-=60;
                    
                }break;
            case 2:
                x += getVelocidade();
                if (x<0) {
                    x+=30;
                }else if(x>29){
                    x-=30;
                    
                }break;
            case 3: 
                x -= getVelocidade();
                if (x<0) {
                    x+=30;
                }else if(x>29){
                    x-=30; 
                }break;
            default:
                break;
        }
    }
}
