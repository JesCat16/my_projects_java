/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoas;

import java.util.ArrayList;

/**
 *
 * @author Jéssica Martins de Jesus
 */
public class PessoaBemInformada extends Pessoa {
    //Constructo usado para realocar um objeto
    public PessoaBemInformada(int x, int y, int whatsapp,ArrayList lista){
        super(x,y,whatsapp,lista);
        setCor(5);
    }
    //Contrutor usado na inicialização da simulação
    public PessoaBemInformada(){
        setCor(5);
    }
    
}
