/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pessoas;

import java.util.ArrayList;

/**
 *
 * @author Jéssica Martins de Jesus
 */
public class PessoaImuniAFakeNews extends Pessoa{
    private int t;
    //coloca a cor correta do objeto
    //Constructo usado para realocar um objeto
    public PessoaImuniAFakeNews(int x, int y, int whatsapp, ArrayList lista) {
        super(x,y,whatsapp,lista);
        setCor(7);
    }

    //get do temporizador
    public int getT() {
        return t;
    }
    //set do temporizador
    public void setT(int t) {
        this.t = t;
    }
    
}
