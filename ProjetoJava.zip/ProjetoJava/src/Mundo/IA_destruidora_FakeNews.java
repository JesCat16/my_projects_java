/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mundo;

/**
 *
 * @author unifjjesus
 */
public class IA_destruidora_FakeNews extends IAs{

    //coloca qual será o número que as coordenadas x e y devem ser para que a situação se aplica
    public IA_destruidora_FakeNews() {
        setId(3);
    }
    
}
