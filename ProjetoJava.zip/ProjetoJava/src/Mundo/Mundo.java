/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mundo;

import Pessoas.PessoaBemInformada;
import Pessoas.PessoaImuniAFakeNews;
import Pessoas.PessoaMalInformada;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Jéssica Martins de Jesus
 */
public class Mundo {
    //arrayList das classes que extendem pessoa
    ArrayList<PessoaBemInformada> pessoabem = new ArrayList<>();
    ArrayList<PessoaMalInformada> pessoamal = new ArrayList<>();
    ArrayList<PessoaImuniAFakeNews> pessoaImune = new ArrayList<>();
    IA_geradora_FakeNews IAGera = new IA_geradora_FakeNews();
    IA_destruidora_FakeNews IADestroi = new IA_destruidora_FakeNews();
    FonteConfiavel FConfiavel = new FonteConfiavel();
    
   //imprime o mundo 
    public Mundo(){
        refazMapa();
    }
    
    
    private int coluna = 1;
    private int [][] mapa;
    
    public void refazMapa(){
        //mapa
        mapa = new int [][]{
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},        
        {1,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
    }; 
    }
    //colori o mapa com a cor de cada objeto
    public void desenhaMundo(){
        for (int i = 0; i < mapa.length; i++){
            for (int j = 0; j < mapa[i].length; j++) {
                switch(mapa[i][j]){
                    case 0:
                        System.out.print(" ");
                        break;
                    case 1:
                        //abilita a tecla esc e troca a cor do background(4) para a cor 7m e depois volta para o padrão 0m(normal)
                        //borda
                        System.out.print("\033[47m \033[0m");
                        break;
                    case 2:
                        //Fonte Confiavel
                        System.out.print("\033[45m \033[0m");
                        break;
                    case 3:
                        //IA destruidora de Fake news
                        System.out.print("\033[44m \033[0m");
                        break;
                    case 4:
                        //Fonte de Fake news
                        System.out.print("\033[46m \033[0m");
                        break;
                    case 5: 
                        //pessoa bem informda
                        System.out.print("\033[42m \033[0m");
                        break;
                    case 6:
                        //pessoa mal informada
                        System.out.print("\033[41m \033[0m");
                        break;
                    case 7:
                        //pessoa imuni a FakeNews
                        System.out.print("\033[43m \033[0m");
                        break;
                    default:
                        break;
                }
            }
            System.out.println();
        }
        System.out.println();
        
    }
    //Adição a lista de WhatsApp e coloca pessoa bem informada no mapa;
    public void colocaMapa(ArrayList<PessoaBemInformada> pessoabem,ArrayList<PessoaMalInformada> pessoamal,ArrayList<PessoaImuniAFakeNews> pessoaImune){
        int xAtual;
        int yAtual;
      
        //For utilizado para adicionar whatsappa as listas de dois objetos quando se tocam para pessoas bem Informadas
        for (int i = 0; i < pessoabem.size(); i++) {
            for (int j = i+1; j < pessoabem.size(); j++) {
                if (pessoabem.get(i).getX() == pessoabem.get(j).getY() && pessoabem.get(i).getY() == pessoabem.get(j).getX()) {
                     //verifica se o whatsapp já esta na lista do objeto, se não esta ele aplica o if.
                    if(pessoabem.get(i).lockForWhats(pessoabem.get(j).getWhatsapp()) == false){
                        //os Whatsapps são trocados, o Whats do objeto a vai para a lista do objeto b e o Whats do objeto b vai para a lista do objeto a;
                        pessoabem.get(i).AdicionarNaLista(pessoabem.get(j).getWhatsapp());
                        pessoabem.get(j).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(i).getX()) == (pessoabem.get(j).getY()-1)) && ((pessoabem.get(i).getY()) == (pessoabem.get(j).getX()))) {
                    if(pessoabem.get(i).lockForWhats(pessoabem.get(j).getWhatsapp()) == false){
                        pessoabem.get(i).AdicionarNaLista(pessoabem.get(j).getWhatsapp());
                        pessoabem.get(j).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(i).getX()) == (pessoabem.get(j).getY()+1)) && ((pessoabem.get(i).getY()) == (pessoabem.get(j).getX()))) {
                    if(pessoabem.get(i).lockForWhats(pessoabem.get(j).getWhatsapp()) == false){
                        pessoabem.get(i).AdicionarNaLista(pessoabem.get(j).getWhatsapp());
                        pessoabem.get(j).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(i).getX()) == (pessoabem.get(j).getY())) && ((pessoabem.get(i).getY()) == (pessoabem.get(j).getX()-1))) {
                    if(pessoabem.get(i).lockForWhats(pessoabem.get(j).getWhatsapp()) == false){
                        pessoabem.get(i).AdicionarNaLista(pessoabem.get(j).getWhatsapp());
                        pessoabem.get(j).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(i).getX()) == (pessoabem.get(j).getY())) && ((pessoabem.get(i).getY()) == (pessoabem.get(j).getX()+1))) {
                    if(pessoabem.get(i).lockForWhats(pessoabem.get(j).getWhatsapp()) == false){
                        pessoabem.get(i).AdicionarNaLista(pessoabem.get(j).getWhatsapp());
                        pessoabem.get(j).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
            }
        }
        
        for (int k = 0; k < pessoabem.size(); k++) {
            //pega x e y da pessoa Bem Informada
            xAtual = pessoabem.get(k).getX();
            yAtual = pessoabem.get(k).getY();
           
            switch(mapa[xAtual][yAtual]){
                case 0:
                    //print pessoa bem informada
                    mapa[xAtual][yAtual] = pessoabem.get(k).getCor();
                    break;
                case 1:
                case 2:
                    //Torna pessoa bem informada em imune a FakeNews
                    if(mapa[xAtual][yAtual] == FConfiavel.getId()){
                    pessoaImune.add(new PessoaImuniAFakeNews (pessoabem.get(k).getX(),pessoabem.get(k).getY(),pessoabem.get(k).getWhatsapp(),pessoabem.get(k).getLista()));
                    pessoabem.remove(k);
                    }
                    break;
                case 3:
                     
                case 4:
                    //Torna pessoa bem informada em pessoa mal Informada
                    if(mapa[xAtual][yAtual] == IAGera.getId()){
                        //pessoas da lista que são bem informadas passam a ser mal Informadas
                     try{
                         //passam pelo ArrayList pessoas bem Informadas e pega o Whatsapp
                        for (int t = 0; t < pessoabem.size(); t++) {
                            //salva o Whatsapp
                            int id = (int) pessoabem.get(t).getWhatsapp();
                            //busca na lista do objeto que passou pela IA destruidora de FakeNews pelo Whatsapp salvo
                                if (pessoabem.get(k).lockForWhats(id)) {
                                    //Se ele encontra a pessoa com essa Whatsapp se era mal Informada passa a ser bem Informada
                                    pessoamal.add(new PessoaMalInformada(pessoabem.get(t).getX(),pessoabem.get(t).getY(),pessoabem.get(t).getWhatsapp(),pessoabem.get(t).getLista()));
                                    pessoabem.remove(t);
                                }
                        }
                       //pessoa que passou pela IA disseminadora de FakeNews, passa a ser mal Informada
                        pessoamal.add(new PessoaMalInformada(pessoabem.get(k).getX(),pessoabem.get(k).getY(),pessoabem.get(k).getWhatsapp(),pessoabem.get(k).getLista()));
                        pessoabem.remove(k);
                        break;
                        }catch(Exception e){
                              
                        }}
                default:
                    break;
            }
        }
    }
    //Adição a lista de WhatsApp e coloca pessoa mal informada no mapa;
    public void colocaMapaMal(ArrayList<PessoaBemInformada> pessoabem,ArrayList<PessoaMalInformada> pessoamal){
        int xAtual;
        int yAtual;
      
        //For utilizado para adicionar whatsappa as listas de dois objetos quando se tocam para pessoas mal Informadas
        for (int i = 0; i < pessoamal.size(); i++) { 
            for (int j = i+1; j < pessoamal.size(); j++) {
                if (pessoamal.get(i).getX() == pessoamal.get(j).getY() && pessoamal.get(i).getY() == pessoamal.get(j).getX()) {
                    //verifica se o whatsapp já esta na lista do objeto, se não esta ele aplica o if.
                    if(pessoamal.get(i).lockForWhats(pessoamal.get(j).getWhatsapp()) == false){
                        //os Whatsapps são trocados, o Whats do objeto a vai para a lista do objeto b e o Whats do objeto b vai para a lista do objeto a;
                        pessoamal.get(i).AdicionarNaLista(pessoamal.get(j).getWhatsapp());
                        pessoamal.get(j).AdicionarNaLista(pessoamal.get(i).getWhatsapp());
                    }
                }
                else if (((pessoamal.get(i).getX()) == (pessoamal.get(j).getY()-1)) && ((pessoamal.get(i).getY()) == (pessoamal.get(j).getX()))) {
                    if(pessoamal.get(i).lockForWhats(pessoamal.get(j).getWhatsapp()) == false){
                        pessoamal.get(i).AdicionarNaLista(pessoamal.get(j).getWhatsapp());
                        pessoamal.get(j).AdicionarNaLista(pessoamal.get(i).getWhatsapp());
                    }
                }
                else if (((pessoamal.get(i).getX()) == (pessoamal.get(j).getY()+1)) && ((pessoamal.get(i).getY()) == (pessoamal.get(j).getX()))) {
                    if(pessoamal.get(i).lockForWhats(pessoamal.get(j).getWhatsapp()) == false){
                        pessoamal.get(i).AdicionarNaLista(pessoamal.get(j).getWhatsapp());
                        pessoamal.get(j).AdicionarNaLista(pessoamal.get(i).getWhatsapp());
                    }
                }
                else if (((pessoamal.get(i).getX()) == (pessoamal.get(j).getY())) && ((pessoamal.get(i).getY()) == (pessoamal.get(j).getX()-1))) {
                    if(pessoamal.get(i).lockForWhats(pessoamal.get(j).getWhatsapp()) == false){
                        pessoamal.get(i).AdicionarNaLista(pessoamal.get(j).getWhatsapp());
                        pessoamal.get(j).AdicionarNaLista(pessoamal.get(i).getWhatsapp());
                    }
                }
                else if (((pessoamal.get(i).getX()) == (pessoamal.get(j).getY())) && ((pessoamal.get(i).getY()) == (pessoamal.get(j).getX()+1))) {
                    if(pessoamal.get(i).lockForWhats(pessoamal.get(j).getWhatsapp()) == false){
                        pessoamal.get(i).AdicionarNaLista(pessoamal.get(j).getWhatsapp());
                        pessoamal.get(j).AdicionarNaLista(pessoamal.get(i).getWhatsapp());
                    }
                }
            }
            //For utilizado para adicionar whatsappa as listas de dois objetos quando se tocam de pessoas bem informadas e mal Informadas
            for (int k = 0; k < pessoabem.size(); k++) {
                for (int o = k+1; o < pessoamal.size(); o++) {
                    if (pessoabem.get(k).getX() == pessoamal.get(o).getY() && pessoabem.get(k).getY() == pessoamal.get(o).getX()) {
                        //verifica se o whatsapp já esta na lista do objeto, se não esta ele aplica o if.
                    if(pessoabem.get(k).lockForWhats(pessoamal.get(o).getWhatsapp()) == false){
                        //os Whatsapps são trocados, o Whats do objeto a vai para a lista do objeto b e o Whats do objeto b vai para a lista do objeto a;
                        pessoabem.get(i).AdicionarNaLista(pessoamal.get(o).getWhatsapp());
                        pessoamal.get(o).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(k).getX()) == (pessoamal.get(o).getY()-1)) && ((pessoabem.get(k).getY()) == (pessoamal.get(o).getX()))) {
                    if(pessoabem.get(k).lockForWhats(pessoamal.get(o).getWhatsapp()) == false){
                        pessoabem.get(k).AdicionarNaLista(pessoamal.get(o).getWhatsapp());
                        pessoamal.get(o).AdicionarNaLista(pessoabem.get(k).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(k).getX()) == (pessoamal.get(o).getY()+1)) && ((pessoabem.get(k).getY()) == (pessoamal.get(o).getX()))) {
                    if(pessoabem.get(k).lockForWhats(pessoamal.get(o).getWhatsapp()) == false){
                        pessoabem.get(k).AdicionarNaLista(pessoamal.get(o).getWhatsapp());
                        pessoamal.get(o).AdicionarNaLista(pessoabem.get(k).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(k).getX()) == (pessoamal.get(o).getY())) && ((pessoabem.get(k).getY()) == (pessoamal.get(o).getX()-1))) {
                    if(pessoabem.get(k).lockForWhats(pessoamal.get(o).getWhatsapp()) == false){
                        pessoabem.get(k).AdicionarNaLista(pessoamal.get(o).getWhatsapp());
                        pessoamal.get(o).AdicionarNaLista(pessoabem.get(i).getWhatsapp());
                    }
                }
                else if (((pessoabem.get(k).getX()) == (pessoamal.get(o).getY())) && ((pessoabem.get(k).getY()) == (pessoamal.get(o).getX()+1))) {
                    if(pessoabem.get(k).lockForWhats(pessoamal.get(o).getWhatsapp()) == false){
                        pessoabem.get(k).AdicionarNaLista(pessoamal.get(o).getWhatsapp());
                        pessoamal.get(o).AdicionarNaLista(pessoabem.get(k).getWhatsapp());
                    }
                }
                }
            }
        }
        
        for (int l = 0; l < pessoamal.size(); l++) {
            //pega x e y da pessoa Mal Informada
            xAtual = pessoamal.get(l).getX();
            yAtual = pessoamal.get(l).getY();
            
            switch(mapa[xAtual][yAtual]){
                case 0:
                    //imprime pesssoa mal informada
                    mapa[xAtual][yAtual] = pessoamal.get(l).getCor();
                    break;
                case 1:
                case 2:
                case 3:
                    //passa pessoa mal informada para bem informada
                    if(mapa[xAtual][yAtual] == IADestroi.getId()){
                        //pessoas da lista que são mal Informadas passam a ser bem informadas
                    try{
                        //passam pelo ArrayList pessoas mal Informadas e pega o Whatsapp
                         for (int t = 0; t < pessoamal.size(); t++) {
                             //salva o Whatsapp
                            int id = (int) pessoamal.get(t).getWhatsapp();
                            //busca na lista do objeto que passou pela IA destruidora de FakeNews pelo Whatsapp salvo
                                if (pessoamal.get(l).lockForWhats(id)) {
                                    //Se ele encontra a pessoa com essa Whatsapp se era mal Informada passa a ser bem Informada
                                    pessoabem.add(new PessoaBemInformada(pessoamal.get(t).getX(),pessoamal.get(t).getY(),pessoamal.get(t).getWhatsapp(), pessoamal.get(t).getLista()));
                                    pessoamal.remove(t);
                                }
                        }  
                     //pessoa que passou pela IA destruidora de FakeNews, passa a ser mal Informada
                    pessoabem.add(new PessoaBemInformada(pessoamal.get(l).getX(),pessoamal.get(l).getY(),pessoamal.get(l).getWhatsapp(), pessoamal.get(l).getLista()));
                    pessoamal.remove(l);
                    break;}catch(Exception e){
                        
                    }
                    }
                    
                default:
                    break;
            }
        }
    }
    //Adição a lista de WhatsApp e coloca pessoa Imuni a FakeNews no mapa;
    public void colocaMapaImuni(ArrayList<PessoaImuniAFakeNews> pessoaImune, ArrayList<PessoaBemInformada> pessoabem, ArrayList<PessoaMalInformada> pessoamal){
        int xAtual;
        int yAtual;
        
        //For utilizado para adicionar whatsappa as listas de dois objetos quando se tocam para pessoas Imunes
        for (int i = 0; i < pessoaImune.size(); i++) {
            for (int j = i+1; j < pessoaImune.size(); j++) {
                if (pessoaImune.get(i).getX() == pessoaImune.get(j).getY() && pessoaImune.get(i).getY() == pessoaImune.get(j).getX()) {
                    //verifica se o whatsapp já esta na lista do objeto, se não esta ele aplica o if.
                    if(pessoaImune.get(i).lockForWhats(pessoaImune.get(j).getWhatsapp()) == false){
                        //os Whatsapps são trocados, o Whats do objeto a vai para a lista do objeto b e o Whats do objeto b vai para a lista do objeto a;
                        pessoaImune.get(i).AdicionarNaLista(pessoaImune.get(j).getWhatsapp());
                        pessoaImune.get(j).AdicionarNaLista(pessoaImune.get(i).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(i).getX()) == (pessoaImune.get(j).getY()-1)) && ((pessoaImune.get(i).getY()) == (pessoaImune.get(j).getX()))) {
                    if(pessoaImune.get(i).lockForWhats(pessoaImune.get(j).getWhatsapp()) == false){
                        pessoaImune.get(i).AdicionarNaLista(pessoaImune.get(j).getWhatsapp());
                        pessoaImune.get(j).AdicionarNaLista(pessoaImune.get(i).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(i).getX()) == (pessoaImune.get(j).getY()+1)) && ((pessoaImune.get(i).getY()) == (pessoaImune.get(j).getX()))) {
                    if(pessoaImune.get(i).lockForWhats(pessoaImune.get(j).getWhatsapp()) == false){
                        pessoaImune.get(i).AdicionarNaLista(pessoaImune.get(j).getWhatsapp());
                        pessoaImune.get(j).AdicionarNaLista(pessoaImune.get(i).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(i).getX()) == (pessoaImune.get(j).getY())) && ((pessoaImune.get(i).getY()) == (pessoaImune.get(j).getX()-1))) {
                    if(pessoaImune.get(i).lockForWhats(pessoaImune.get(j).getWhatsapp()) == false){
                        pessoaImune.get(i).AdicionarNaLista(pessoaImune.get(j).getWhatsapp());
                        pessoaImune.get(j).AdicionarNaLista(pessoaImune.get(i).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(i).getX()) == (pessoaImune.get(j).getY())) && ((pessoaImune.get(i).getY()) == (pessoaImune.get(j).getX()+1))) {
                    if(pessoaImune.get(i).lockForWhats(pessoaImune.get(j).getWhatsapp()) == false){
                        pessoaImune.get(i).AdicionarNaLista(pessoaImune.get(j).getWhatsapp());
                        pessoaImune.get(j).AdicionarNaLista(pessoaImune.get(i).getWhatsapp());
                    }
                }
                //For utilizado para adicionar whatsappa as listas de dois objetos quando se tocam de pessoas Imunes e pessoas Bem Informadas
                for (int k = 0; k < pessoaImune.size(); k++) {
                    for (int l = 0; l < pessoabem.size(); l++) {
                  if (pessoaImune.get(k).getX() == pessoabem.get(l).getY() && pessoaImune.get(k).getY() == pessoabem.get(l).getX()) {
                   //verifica se o whatsapp já esta na lista do objeto, se não esta ele aplica o if.
                    if(pessoaImune.get(k).lockForWhats(pessoabem.get(l).getWhatsapp()) == false){
                        //os Whatsapps são trocados, o Whats do objeto a vai para a lista do objeto b e o Whats do objeto b vai para a lista do objeto a;
                        pessoaImune.get(k).AdicionarNaLista(pessoabem.get(l).getWhatsapp());
                        pessoabem.get(l).AdicionarNaLista(pessoaImune.get(k).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(k).getX()) == (pessoabem.get(l).getY()-1)) && ((pessoaImune.get(k).getY()) == (pessoabem.get(l).getX()))) {
                    if(pessoaImune.get(k).lockForWhats(pessoabem.get(l).getWhatsapp()) == false){
                        pessoaImune.get(k).AdicionarNaLista(pessoabem.get(l).getWhatsapp());
                        pessoabem.get(l).AdicionarNaLista(pessoaImune.get(k).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(k).getX()) == (pessoabem.get(l).getY()+1)) && ((pessoaImune.get(k).getY()) == (pessoabem.get(l).getX()))) {
                    if(pessoaImune.get(k).lockForWhats(pessoabem.get(l).getWhatsapp()) == false){
                        pessoaImune.get(k).AdicionarNaLista(pessoabem.get(l).getWhatsapp());
                        pessoabem.get(l).AdicionarNaLista(pessoaImune.get(k).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(k).getX()) == (pessoabem.get(l).getY())) && ((pessoaImune.get(k).getY()) == (pessoabem.get(l).getX()-1))) {
                    if(pessoaImune.get(k).lockForWhats(pessoabem.get(l).getWhatsapp()) == false){
                        pessoaImune.get(k).AdicionarNaLista(pessoabem.get(l).getWhatsapp());
                        pessoabem.get(l).AdicionarNaLista(pessoaImune.get(k).getWhatsapp());
                    }
                }
                else if (((pessoaImune.get(k).getX()) == (pessoabem.get(l).getY())) && ((pessoaImune.get(k).getY()) == (pessoabem.get(l).getX()+1))) {
                    if(pessoaImune.get(k).lockForWhats(pessoabem.get(l).getWhatsapp()) == false){
                        pessoaImune.get(k).AdicionarNaLista(pessoabem.get(l).getWhatsapp());
                        pessoabem.get(l).AdicionarNaLista(pessoaImune.get(k).getWhatsapp());
                    }
                }
                    }
                }
            }
        }
        
        for (int k = 0; k < pessoaImune.size(); k++) {
            //pega x e y da pessoa Imune
            xAtual = pessoaImune.get(k).getX();
            yAtual = pessoaImune.get(k).getY();
            switch(mapa[xAtual][yAtual]){
                case 0:
                    //imprime pessoa imune
                     mapa[xAtual][yAtual] = pessoaImune.get(k).getCor();
                case 1:
                    //contador para limitar o tempo que a pessoa fica imune
                 if(pessoaImune.get(k).getT() < 30){
                     //se t estiver menor que 30 ele só aumenta o T
                    pessoaImune.get(k).setT((pessoaImune.get(k).getT()) + 1);
                    break;
                }else{
                     //se não o objeto passa a ser pessoa bem Informada
                    pessoabem.add(new PessoaBemInformada(pessoaImune.get(k).getX(),pessoaImune.get(k).getY(),pessoaImune.get(k).getWhatsapp(), pessoaImune.get(k).getLista()));
                    pessoaImune.remove(k);
            }
            }
              
            
                
        }
    }
}
