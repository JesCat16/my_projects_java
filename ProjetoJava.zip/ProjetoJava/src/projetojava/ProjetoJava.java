/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetojava;

import Mundo.Mundo;
import Pessoas.PessoaBemInformada;
import Pessoas.PessoaImuniAFakeNews;
import Pessoas.PessoaMalInformada;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Jéssica Martins de Jesus
 */
public class ProjetoJava {

    public static void main(String[] args) {
        // ArrayList de cada classe que extende pessoa
        ArrayList<PessoaBemInformada> pessoabem = new ArrayList<>();
        ArrayList<PessoaMalInformada> pessoamal = new ArrayList<>();
        ArrayList<PessoaImuniAFakeNews> pessoaImune = new ArrayList<>();
       
        //imprime mundo
        Mundo m = new Mundo();
        //usado para imprimir o tempo da simulação
        Date tempo_inicio = new Date();
        
        //cria pessoas bem informadas
        for (int i = 0; i < 100; i++) {
         pessoabem.add(new PessoaBemInformada());
         
        }
        
        //simulação
        while(true){
            m.refazMapa();
            //faz com que os objetos se movam
            for (int j = 0; j < pessoabem.size(); j++) {
                pessoabem.get(j).mover(); 
            }
            for (int h = 0; h < pessoamal.size(); h++) {
                pessoamal.get(h).mover(); 
            }
            for (int g = 0; g < pessoaImune.size(); g++) {
                pessoaImune.get(g).mover(); 
                //pessoaImune.get(g).printLista();
            }
            //
            Date current_time = new Date();
            
            //coloca os objetos no mapa
            m.colocaMapa(pessoabem,pessoamal,pessoaImune);
            m.colocaMapaMal(pessoabem, pessoamal);
            m.colocaMapaImuni(pessoaImune,pessoabem,pessoamal);
            //
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println("===========================================");
            System.out.println("Tempo de simulação: " + ((current_time.getTime()-tempo_inicio.getTime())/1000));
            System.out.println("\u001b[42m \033[0m Bem Informadas: " + pessoabem.size()+"  ");
            System.out.println("\u001b[41m \033[0m Mal Informadas: " + pessoamal.size()+"  ");
            System.out.println("\u001b[43m \033[0m Imunes a Fake News: " + pessoaImune.size()+"  ");
            System.out.println();
            //desenha o mapa na tela com os objetos se movendo
            m.desenhaMundo();
            try{
                //faz uma pausa entre prints
                Thread.sleep(500);
            }catch(Exception e){
                e.printStackTrace();
            }
            
    }
    }
    
}
